<div id="footer_line" ></div>
	<div id="footer">
				<h2>Encode Dan Decode</h2>
				<span style="float:left">Design by <a href="http://twitter.com/BangDevilz" target="_blank">AnonSecTeam.inc</a> Logo © <a href="http://www.facebook.com/dhodoy.saostiram" target="_blank">AnonSecTeam</a></span><span style="float:right">All rights reserved | <a href="http://indonesianbacktrack.or.id/forum/private.php?action=send&uid=10863" target="_blank">Contact Us</a></span>
				<br /><br /><br />
			</div>
		</div>