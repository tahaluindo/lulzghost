<a href="encrypt.php?algorithm=hex">
					<div class="service">
						<div class="text">
							Hex
						</div>
					</div>
				</a>
				<a href="encrypt.php?algorithm=binary">
				<div class="service">
					<div class="text">
						Binary
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=base64">
				<div class="service">
					<div class="text">
						Base64
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=md5">
				<div class="service">
					<div class="text">
						MD5
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=sha1">
				<div class="service">
					<div class="text">
						SHA1
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=rot13">
				<div class="service">
					<div class="text">
						ROT13
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=des">
				<div class="service">
					<div class="text">
						DES hash
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=sha256">
				<div class="service">
					<div class="text">
						SHA256
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=htmlentities">
				<div class="service">
					<div class="text">
						HTML entities
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=whirlpool">
				<div class="service">
					<div class="text">
						Whirlpool
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=urlencode">
				<div class="service">
					<div class="text">
						URL encode
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=md4">
				<div class="service">
					<div class="text">
						MD4
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=sha512">
				<div class="service">
					<div class="text">
						SHA512
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=md2">
				<div class="service">
					<div class="text">
						MD2
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=sha384">
				<div class="service">
					<div class="text">
						SHA384
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=ripemd128">
				<div class="service">
					<div class="text">
						RIPEMD-128
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=ripemd160">
				<div class="service">
					<div class="text">
						RIPEMD-160
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=ripemd256">
				<div class="service">
					<div class="text">
						RIPEMD-256
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=ripemd320">
				<div class="service">
					<div class="text">
						RIPEMD-320
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=gost">
				<div class="service">
					<div class="text">
						GOST
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=snefru">
				<div class="service">
					<div class="text">
						Snefru
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=snefru256">
				<div class="service">
					<div class="text">
						Snefru-256
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=adler32">
				<div class="service">
					<div class="text">
						Adler32
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=crc32">
				<div class="service">
					<div class="text">
						Crc32
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=crc32b">
				<div class="service">
					<div class="text">
						Crc32b
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=esab46">
				<div class="service">
					<div class="text">
						Esab46
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=reverse">
				<div class="service">
					<div class="text">
						Reverse
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=uppercase">
				<div class="service">
					<div class="text">
						Uppercase
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=lowercase">
				<div class="service">
					<div class="text">
						Lowercase
					</div>
				</div>
				</a>
				<a href="encrypt.php?algorithm=morse">
				<div class="service">
					<div class="text">
						Morse
					</div>
				</div>
				</a>
