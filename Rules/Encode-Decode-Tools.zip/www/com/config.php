<?php
##################Settings#######################
//This settings will be used in seo pourpouses
$site_name        = ' Encrypting & Encoding Script'; //site name
$site_description = ' Encryption over 30 encryption altghoritms, like hex, binary, base64, Whirpool,md5 ,SHA, ROT13, and so many others.';//site description (~250 characters)
$site_keywords    = 'binary,des,hex,online converter';//a few keywords,separated by a comma
#################################################
require_once('functions.php');
?>